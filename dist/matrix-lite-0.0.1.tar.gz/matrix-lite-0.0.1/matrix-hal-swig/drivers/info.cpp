#include "info.h"
#include "../matrix.h"

info::info(){}
info::~info(){}

// Determine if MATRIX is using bus or kernel modules
bool info::isDirectBus(){
  if(!bus.IsDirectBus())
    return false;
  else
    return true;
}