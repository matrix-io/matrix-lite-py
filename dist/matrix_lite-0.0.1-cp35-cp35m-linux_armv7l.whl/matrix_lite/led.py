from halSwig import everloop, led

everloop = everloop()

def ledTest():
    print(everloop.ledCount)
    print("LED TEST WORKEDD :D:D:D:D:D:D")