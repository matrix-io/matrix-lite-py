def gpioTest():
    print("GPIO TEST WORKEDD WUHUHUHUHUHUH")